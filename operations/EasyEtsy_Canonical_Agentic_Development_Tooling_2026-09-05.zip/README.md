# EasyEtsy Canonical Resource Pack — 2026-09-05

Files:
- `CANONICAL_RESOURCE.md` — complete research + architecture + recommendations
- `tool_registry.json` — machine-readable registry of the Etsy tooling landscape
- `BUILD_BLUEPRINT.md` — implementation blueprint for the EasyEtsy stack
- `README.md` — this file

The registry is intentionally opinionated: it distinguishes official/supported execution paths from third-party estimates and policy-risky scraping approaches.
